grant usage on *.* to 'pii_customers'@'localhost';
drop user 'pii_customers'@'localhost';
drop database if exists pii_db;
create database pii_db;
flush privileges;
use pii_db;
create table customers (
  id integer auto_increment primary key,
  member_id varchar(12) not null,
  name varchar(64) not null,
  address varchar(64) not null,
  telephone varchar(32) not null,
  birthdate varchar(10) not null,
  email varchar(64) not null
);
create user 'pii_customers'@'localhost';
grant all on pii_db.* to 'pii_customers'@'localhost' identified by 'voltage123';
flush privileges;

