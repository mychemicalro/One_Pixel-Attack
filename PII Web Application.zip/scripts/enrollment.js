//JavaScript code for PII demo (Customer Loyalty)

//Total names in each array
var numberNames = 84;

//Array of first name strings
var firstNames = [ "Alex", "Andy", "Abigail", "Alice", "Bob", "Ben", "Becky", "Bridget", "Carl", "Craig", "Cindy", "Clara", "Doug", "Dagwood", "Debbie", "Darla", 
"Ed", "Evan", "Elisa", "Erin", "Fred", "Frank", "Fran", "Freda", "George", "Greg", "Grace", "Giselle", "Henry", "Howard", "Heather", "Helga",
"Iggie", "Irwin", "Inga", "Ilvire", "Jason", "Jamin", "Jennifer", "Jasmine", "Karl", "Ken", "Karen", "Karla", "Larry", "Lloyd", "Lacy", "Lila", 
"Max", "Melvin", "Mary", "Myrtle", "Nevin", "Noyce", "Nina", "Nellie", "Oscar", "Oswald", "Olivia", "Orchard", "Paul", "Peter", "Patricia", "Pearl",
"Ron", "Ralph", "Racine", "Raleigh", "Sam", "Steve", "Sara", "Susan", "Tom", "Terrance", "Trish", "Trina", "Vance", "Vinnie", "Violet", "Vivian",
"Walter", "William", "Wyona", "Wanda" ];

//Array of last name strings
var lastNames = [ "Applewood", "Abernathy", "Archer", "Allen", "Babcock", "Bouchet", "Braxton", "Bouregard", "Carter", "Crabner", "Cillikia", "Connor",
"Destrehan", "Denver", "Dalles", "Dortmund", "Esplanade", "Eisenhower", "Ereleven", "Entimani", "Farenheit", "Fabrege", "Factor", "Frichand",
 "Gregord", "Griswild", "Grandeur", "Grenthasman", "Hughes", "Hyatt", "Hilibrand", "Hortmund", "Ivanderson", "Intregart", "Inglemani", "Itvanictas",
 "Jerroldman", "Journeyman", "Janparhet", "Jambalaya", "Kragen", "Kazarian", "Karmanathis", "Kreetveltd", "Landerson", "Lillihamer", "Livithian", "Lomanezhik",
 "Mantrouse", "Mingleson", "Mentromeshyan", "Mervelindink", "Noyce", "Nirivenhan", "Normalitz", "Nivendian", "Oscarenolyds", "Onnasian", "Omnivoranious", "Ortmund",
 "Pulzheniki", "Pantroseman", "Pederson", "Pevalk", "Randstone", "Rismund", "Regalathner", "Ripicon", "Sampson", "Stevenson", "Splederuhi", "Spigner",
 "Talbot", "Terenevedt", "Tetrehedri", "Terminalousouki", "Venessian", "Vaughn", "Vereni", "Vivelman", "Wiferdson", "Worth", "Wentword", "Wineldyk" ];

//Total domains for email address generation
var numberDomains = 14;

//Array of domain strings
var domains = [ "@gmail.com", "@outlook.com", "@voltage.com", "@yahoo.com", "@hotmail.com", "@mail.ru", "@facebook.com", "@vivaldi.nl", "@fletchers.co.uk", "@lederhosen.de", "@xs4all.nl", "@aol.com", "@hotlook.com", "@ymail.com" ]

//Array of street names. Same number as people names.
var streets = [ "Aberdeen", "Atlantic", "Avondale", "Arcade", "Baltic", "Blue Lake", "Bloomfield", "Brunswick",
"Caliente", "Cumberland", "Cinnabar", "Crossvale", "Dakota", "Daunting", "Dreadle", "Drummond",
"Eagle Crest", "Embarcadero", "Edwards", "Enfinante", "First", "Flushing", "Fair Oaks", "Fremont",
"Groundling", "Geddenheim", "Gillageo", "Garamond", "Height", "Hayecenth", "Halycorn", "Himilaya",
"Ingersoll", "Infinite", "Intrepid", "Instititutional", "Jasper", "J", "Jasper", "Jwezchesky",
"Knight", "Kildare", "Kvetching", "Krystal", "Lambda", "Links", "Letterfield", "Lincoln",
"Major", "Manhattan", "Morrow Ring", "Manchester", "Nocturne", "Nrelyand", "Nividji", "Narrell",
"Octavius", "Octal", "Omnibus", "Oval", "Pepperland", "Pfeiland", "Pollack", "Pepper",
"Richmond", "Relative", "Recursive", "Random", "Stepanikurt", "Sebastian", "Stafford", "Sleschinger",
"Trimble", "Toscany", "Tlevert", "Townsend", "Vancouver", "Vanilla", "Van Hooford", "Vintoner",
"Welch", "Worstwood", "Wimbledon", "Wrought Iron" ];


//Number of different street suffixes
var numberStreetTypes = 9;

//Strings for each street type
var streetTypes = [ "Boulevard", "Street", "Lane", "Court", "Place", "Parkway", "Avenue", "Expressway", "Ring" ];

function genRandom(range) //Generates random numbers in the range 0..range - 1
//Add 1 for numbers 1..range
{
	return Math.floor(Math.random() * range);
}

//Generates a telephone prefix (three digits)

function areaPrefix()
{
  return "" + (genRandom (7) + 2 ) + genRandom(10) + (genRandom(8) + 1);
}
 

//Generates a telephone number that is country specific
function getPhone()
{
  country = genRandom(6);

  switch(country)
  {
    case 0: //Belgium
      return "+32 4" + (genRandom(90) + 10) + " "
        + (genRandom(90) + 10) + " "
        + (genRandom(90) + 10) + " "
        + (genRandom(90) + 10);
    case 1: //France
      return "+33 " + (genRandom(4) + 1) + " "
        + (genRandom(90) + 10) + " "
        + (genRandom(90) + 10) + " "
        + (genRandom(90) + 10) + " "
        + (genRandom(90) + 10);
    case 2: //Germany
      return "+49 " +
        + (genRandom(9000) + 1000) + " "
        + (genRandom(900000) + 100000);
    case 3: //Netherlands
      return "+31 " + (genRandom(90) + 10) + " "
        + (genRandom(9000) + 1000) + " "
        + (genRandom(900) + 1000) + " "
        + (genRandom(900) + 1000);
    case 4: //UK
      return "+44 " + 
        + (genRandom(9000) + 1000) + 
        + (genRandom(900) + 1000);
    default:
      return "(" + areaPrefix() + ") " + areaPrefix() + "-" + areaPrefix() + genRandom(10);
    }
}

//Generates member ID strings in UUUDDDDDDDD format
function getMemberId()
{
	return String.fromCharCode(65 + genRandom (25)) + String.fromCharCode(65 + genRandom (25)) + String.fromCharCode(65 + genRandom (25))
	+ areaPrefix() + areaPrefix() + areaPrefix();
}

//Generates date strings in MM/DD/YYYY
function getDate()
{
	month = "" + (genRandom(12) + 1);
	if (month.length < 2)
	{
	  month = "0" + month;
	}
	day = "" + (genRandom(28) + 1);
	if (day.length < 2)
	{
	  day = "0" + day;
	}

	return day + "/" + month + "/" + (genRandom(50) + 1960);
}

//Generates EU style street address
function getAddress()
{
  return streets[genRandom(numberNames)] + " "
  + streetTypes[genRandom(numberStreetTypes)] + " "
  + (genRandom(1000) + 1) + genRandom(10);
}


//Fills out all data fields in the form
function populateForm()
{
	document.getElementById("MemberId").value = getMemberId();
	firstName = firstNames[genRandom(numberNames)];
	lastName = lastNames[genRandom(numberNames)];
	document.getElementById("Name").value = firstName + " " + lastName;
	document.getElementById("Address").value = getAddress();
	document.getElementById("Phone").value = getPhone();
	document.getElementById("Birthdate").value = getDate();
	emailAddress = firstName + "." + lastName + domains[genRandom(numberDomains)];
	document.getElementById("Email").value = emailAddress.toLowerCase();
}


//Verifies the data items in the form match validation rules 
function validateForm()
{
	var parsingError = false;
	var errorMessage = "Please correct the following field entries:\n\n";
	
	//Member ID
	var validMember = /[A-Z]{3}[0-9]{9}/;
	
	if (!validMember.test(document.getElementById("MemberId").value))
	{
		parsingError = true;
		errorMessage += "- Member must be three capital letters followed by nine digits.\n";
	}
	
	var validName = /.{4}.+/;
	if (!validName.test(document.getElementById("Name").value))
	{
		parsingError = true;
		errorMessage += "- Name must be at least five characters.\n";
	}

	var validAddress = /.{9}.+/
	if (!validAddress.test(document.getElementById("Address").value))
	{
		parsingError = true;
		errorMessage += "- Address must be at least ten characters.\n";
	}
	
	var validPhone = /\(|\+|\ |[0-9]{8,99}/;
	if (!validPhone.test(document.getElementById("Phone").value))
	{
		parsingError = true;
		errorMessage += "- Phone must be digits and other valid phone number characters.\n";
	}
	
	var validDate = /[0-9]{2}\/[0-9]{2}\/[1-9][0-9]{3}/;
	if (!validDate.test(document.getElementById("Birthdate").value))
	{
		parsingError = true;
		errorMessage += "- Date must be in DD/MM/YYYY format with no lead zero on year.\n";
	}
	
	var validEmail = /^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+/;
	if (!validEmail.test(document.getElementById("Email").value))
	{
		parsingError = true;
		errorMessage += "- Email must be in standard format.";
	}
	
	if (parsingError)
	{
		alert (errorMessage);
	}
	else
	{
		document.forms["enrollment"].submit();
	}
}
