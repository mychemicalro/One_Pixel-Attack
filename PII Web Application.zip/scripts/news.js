var webLinks = [
"http://www.retaildive.com/news/the-real-cost-of-a-data-breach/363587/",
"http://www.bbc.com/news/technology-32901890",
"http://www.retailtimes.co.uk/majority-customers-shun-brands-following-data-breach-research-reveals/",
"http://www.computerweekly.com/news/2240203760/EU-data-breach-disclosures-to-be-enforced-soon",
"http://www.retail-loyalty.org/en/news/p-f-chang-s-investigates-data-breach-report/",
"http://www.eudataprotectionlaw.com/fines/",
"http://www.bloomberg.com/news/articles/2013-10-21/eu-panel-backs-fines-up-to-137-million-in-privacy-law"
]

var maxLink = 6;
var minLink = 0;
var articlePrefix = "news";
var articlePostfix = ".png";
var currentArticle = 6;

function openArticle()
{
  window.open(webLinks[currentArticle]);
}

function loadArticle(offset)
{
  currentArticle += offset;
  
  if (currentArticle > maxLink)
  {
    currentArticle = minLink;
  }
  else if (currentArticle < minLink)
  {
    currentArticle = maxLink;
  }

  document.getElementById("newsArticle").src = "images/" + articlePrefix + currentArticle + articlePostfix;
}

function loopArticle()
{
  setInterval(function() {loadArticle(1)}, 10000);
}

document.body.onload = function() {loopArticle()};

