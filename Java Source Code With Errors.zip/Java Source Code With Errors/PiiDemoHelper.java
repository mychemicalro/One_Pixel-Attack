package com.voltage.demo.customer;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Date;

public class PiiDemoHelper
{
  private Connection db;
  private Statement query;

  public PiiDemoHelper () throws Exception
  {
    Class.forName("com.mysql.jdbc.Driver");
    db = DriverManager.getConnection("jdbc:mysql://localhost/your pii database", "your database user name (w/o host name)", "your database password");
  }

  public int insert (Customer customerRecord) throws Exception
  {
    String sql = "INSERT INTO customers VALUES (0, '"; //A primary key of zero means use the auto increment value
    sql += customerRecord.member_id + "', '";
    sql += customerRecord.name + "', '";
    sql += customerRecord.address + "', '";
    sql += customerRecord.telephone + "', '";
    sql += customerRecord.birthdate + "', '";
    sql += customerRecord.email + "');";

    query = db.createStatement();
    System.out.println ("Executing sql statement " + sql);
    return query.executeUpdate(sql) - 1; //When inserting one row, 1 - 1 == 0!
  }

  public ResultSet queryCustomers () throws SQLException
  {
    String sql = "SELECT member_id, name, address, telephone, birthdate, email FROM customers;";
    query = db.createStatement();
    query.execute(sql);
    return query.getResultSet();
  }

  public void flushDatabase () throws Exception
  {
      String sql = "DELETE FROM customers;"; //delete all rows
      query = db.createStatement();
      System.out.println ("Executing sql statement " + sql);
      query.executeUpdate(sql);
  }

}