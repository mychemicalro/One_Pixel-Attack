package com.voltage.demo.context;

import com.voltage.securedata.enterprise.LibraryContext;
import com.voltage.securedata.enterprise.VeException;
import com.voltage.vibesimple.VibeSimple;
import com.voltage.vibesimple.VibeSimple_Service;

import java.io.File;
import java.net.URL;
import java.net.MalformedURLException;

public class LibraryContextLoader {

  private static final String POLICY_URL            = "Your policy URL";
  private static final String WSDL_URL              = "Your WSDL URL";
  private static final String TRUST_STORE_DIRECTORY = "Your Simple API certificate directory (absolute path)";

  private static LibraryContext singletonLibraryContext = null;
  private static VibeSimple singletonService = null;

  private static synchronized void initLibraryContext() throws VeException
  {
    if (singletonLibraryContext == null)
    {
      System.loadLibrary("vibesimplejava");
      System.out.println("Loading LibraryContext version " + LibraryContext.getVersionNumber());

      //Verify we can read the certificate cache
      File checkTrustStore = new File(TRUST_STORE_DIRECTORY);

      if (checkTrustStore != null && checkTrustStore.canRead())
      {
         System.out.print ("Able to read " + TRUST_STORE_DIRECTORY);
      }
      else
      {
        System.out.print ("Could not open " + TRUST_STORE_DIRECTORY);
      }
      System.out.println (" as the trust store directory.");
      System.out.flush();

      singletonLibraryContext = new LibraryContext.Builder()
        .setPolicyURL(POLICY_URL)
        .setTrustStorePath(TRUST_STORE_DIRECTORY)
        .enableMemoryCache(true)
        .build();
    }
  }

  private static synchronized void initService() throws MalformedURLException
  {
    if (singletonService == null)
    {
      URL wsdlURL = new URL(WSDL_URL);
      singletonService = (new VibeSimple_Service(wsdlURL)).getVibeSimpleSOAP();
    }
  }

  public static LibraryContext getLibraryContext() throws VeException
  {
    initLibraryContext();
    return singletonLibraryContext;
  }

  public static VibeSimple getService() throws MalformedURLException
  {
    initService();
    return singletonService;
  }
}